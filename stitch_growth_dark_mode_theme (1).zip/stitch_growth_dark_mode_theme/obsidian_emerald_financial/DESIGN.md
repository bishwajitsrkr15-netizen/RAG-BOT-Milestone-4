---
name: Obsidian Emerald Financial
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#bacac1'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#85948c'
  outline-variant: '#3c4a43'
  surface-tint: '#2fe0aa'
  primary: '#44edb7'
  on-primary: '#003828'
  primary-container: '#00d09c'
  on-primary-container: '#00533c'
  inverse-primary: '#006c4f'
  secondary: '#59dac9'
  on-secondary: '#003731'
  secondary-container: '#00a899'
  on-secondary-container: '#00352f'
  tertiary: '#bcd6f4'
  on-tertiary: '#18324a'
  tertiary-container: '#a0bad8'
  on-tertiary-container: '#314a63'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#59fdc5'
  primary-fixed-dim: '#2fe0aa'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#79f7e5'
  secondary-fixed-dim: '#59dac9'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#cfe5ff'
  tertiary-fixed-dim: '#afc9e7'
  on-tertiary-fixed: '#001d34'
  on-tertiary-fixed-variant: '#304962'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-mono-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.02em
  data-mono-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system establishes a focused, high-precision environment for personal wealth management, market analytics, and investment execution. It balances the technological agility of modern fintech with institutional-grade seriousness and credibility. 

Key attributes:
- **Atmospheric & Immersive:** A rich, deep dark mode interface that eliminates visual glare, reducing fatigue during extended tracking sessions.
- **Analytical Precision:** Layouts prioritize clarity of numerical data, performance delta indicators, and transaction workflows over decorative flourishes.
- **Controlled Vibrancy:** High-energy mint emerald accents are applied selectively to positive yield indicators, primary actions, and focused states, maintaining strict contrast without causing visual exhaustion.
- **Tactile Modernism:** A hybrid style blending deep slate surfaces, subtle micro-borders, and gentle ambient elevations to create physical hierarchy in digital space.

## Colors
The palette utilizes dark architectural tones contrasted against vivid functional status colors.

### Base Canvases & Surfaces
- **Canvas Base:** `#121212` — Primary canvas background for zero-reflection viewing.
- **Canvas Sub-layer:** `#181A20` — Secondary page background and deep inset zones.
- **Surface Level 1 (Default Card):** `#20242D` — Standard elevated cards, panels, and table containers.
- **Surface Level 2 (Elevated / Overlay):** `#262B35` — Modals, popovers, hovering rows, and nested card states.
- **Border Subtle:** `#2E3440` — Standard container dividers and card outlines (1px).
- **Border Active / Muted:** `#333946` — Input strokes, active chip containers, and hovered element borders.

### Accents & Indicators
- **Primary Mint (`#00D09C`):** Reserved for core transactional calls to action, active navigation tabs, positive portfolio shifts, and verified tags.
- **Secondary Teal (`#2BB8A8`):** Informational highlights, auxiliary progress charts, and secondary actionable accents.
- **Tertiary Slate (`#5A738E`):** Graph grid lines, inactive slider tracks, and tertiary container states.
- **Semantic Red / Bearish (`#EB5757`):** Explicitly reserved for negative price swings, liquidation warnings, and destructive actions.

### Typography & Icons
- **Text High-Contrast:** `#FFFFFF` — Primary headings, critical data, current balances, and values.
- **Text Medium-Contrast:** `#9EACB9` — Field labels, table headers, breadcrumbs, and timestamp indicators.
- **Text Disabled / Tertiary:** `#5F6B7A` — Placeholder text, disabled buttons, and secondary borders.

## Typography
Plus Jakarta Sans serves across headlines, body copy, and UI controls to deliver a modern geometric silhouette with wide open apertures suited for dark mode reading.

Rules for financial typographic presentation:
- **Numerical Alignment:** Financial columns, order book depths, and ledger quantities must render using tabular figure settings (`font-variant-numeric: tabular-nums lining-nums`) to preserve column alignment across real-time value changes.
- **Negative Spacing:** Large currency headlines apply subtle negative letter-spacing to prevent numerical fragmentation.
- **Hierarchy Separation:** Labels never compete with asset values. Metric values display in pure white (`#FFFFFF`) with regular or medium weight, while the metric classification sits above or beside in `#9EACB9` at `label-md` or `label-sm`.

## Layout & Spacing
The layout uses a multi-tier responsive grid engineered for dense financial interfaces, data tables, and high-frequency analytical panels.

### Structural Framework
- **Desktop (>= 1200px):** 12-column responsive fluid grid with 2rem outer margins and 1.5rem column gutters. Maximum content bounds cap at 1440px to optimize line lengths in detailed market review panels.
- **Tablet (768px - 1199px):** 8-column layout with 1.5rem margins and 1rem gutters. Portfolio and asset analytics collapse into split single-column cards.
- **Mobile (< 768px):** 4-column layout with 1rem margins and 0.75rem gutters. Dense financial tables transition to scrollable horizontal matrices or structured list cards.

### Spacing Strategy
Padding within data containers follows a generous rhythm to offset the visual density of real-time metrics. Content within summary cards utilizes `space-lg` (24px) padding, while dense order tables and transactional receipts compress to `space-md` (16px) vertical rhythms with `space-sm` (8px) inter-row separation.

## Elevation & Depth
Elevation is achieved using tonal layering combined with 1px structural micro-borders and soft ambient shadows. Pure black drops are avoided in favor of deep, diffused indigo-charcoal shadows that ground floating cards.

### Layer Stack
1. **Level 0 (Canvas):** `#121212` — Base layer, no shadow, non-interactive backdrop.
2. **Level 1 (Card Layer):** `#20242D` — 1px border using `#2E3440`, accompanied by an ambient drop shadow: `0 4px 20px -2px rgba(0, 0, 0, 0.45)`.
3. **Level 2 (Hover & In-Focus Cards):** `#262B35` — 1px border shifting to `#333946`, shadow: `0 8px 30px -4px rgba(0, 0, 0, 0.6)`.
4. **Level 3 (Modals & Command Palettes):** `#262B35` — 1px border `#333946`, shadow: `0 16px 48px 0 rgba(0, 0, 0, 0.75)`.

To signify active interactive items without clutter, primary focal containers apply an ultra-subtle inset highlight: `inset 0 1px 0 0 rgba(255, 255, 255, 0.05)`.

## Shapes
The shape language uses balanced rounded rectangles, reinforcing an approachable yet structured aesthetic.

- **Primary Cards & Panels:** Standardized to `rounded-lg` (16px / 1rem) to frame data sets cleanly without sharp visual breaks.
- **Input Fields & Buttons:** Standardized to `rounded` (8px / 0.5rem) to maintain distinct visual separation between structural containers and actionable controls.
- **Pills & Status Chips:** Full pill roundedness (`9999px`) to immediately distinguish contextual status tags, asset classes, and time filters from structural layout boxes.

## Components

### Buttons
- **Primary Action (Buy / Invest / Submit):** Solid `#00D09C` background, `#121212` bold label text (`label-lg`). Height 44px (desktop) / 48px (mobile), border radius 8px. Hover state brightens with a subtle luminance shift (`#05E5AC`); active state compresses down 1px.
- **Secondary Action:** Transparent background with a 1px border in `#333946`, text color `#FFFFFF`. Hover transitions the background to `#262B35` and border to `#5A738E`.
- **Tertiary / Ghost:** No border or background; text in `#9EACB9`. Hover shifts text to `#FFFFFF` with an ambient `#20242D` rounded surface.

### Chips & Filter Pills
- **Filter Chips:** 32px height, fully rounded pill shape. Default state has a `#20242D` background, 1px `#2E3440` border, and `#9EACB9` text (`label-md`). Selected state features a subtle 12% opacity mint tint (`rgba(0, 208, 156, 0.12)`), `#00D09C` border, and crisp `#00D09C` text.
- **Gain / Loss Indicators:** Ultra-compact tags (20px height) with 4px border radius. Positive returns use `rgba(0, 208, 156, 0.15)` fill with `#00D09C` text; negative returns use `rgba(235, 87, 87, 0.15)` fill with `#EB5757` text.

### Form Inputs
- **Text & Currency Inputs:** Container background `#181A20`, 1px border `#2E3440`, height 48px, border radius 8px, content text `#FFFFFF` (`body-md`), label placed floating or upper-stacked in `#9EACB9` (`label-sm`).
- **Focus State:** Border shifts cleanly to `#00D09C` with a 2px outer glow (`rgba(0, 208, 156, 0.2)`). No default browser outlines.

### Data Cards & Metrics
- **Metric Card:** Background `#20242D`, 1px border `#2E3440`, 16px border radius. Padding set to 20px or 24px. The primary metric sits prominently in `headline-lg` (`#FFFFFF`), with supporting timeframe indicators aligned underneath in `label-sm` (`#9EACB9`).
- **Asset List Rows:** Border-bottom 1px `#2E3440`. Background transparent, shifting to `#262B35` on hover with a smooth 150ms transition. Left lockup displays company icon, ticker symbol, and asset category; right lockup aligns price and 24h percentage delta.

### Toggles, Checkboxes & Radios
- **Checkbox:** 18x18px square with 4px radius, 1px border `#333946`. When checked, background fills with `#00D09C` showing a `#121212` checkmark icon.
- **Switch:** 40px width, 22px height pill track in `#262B35`. Thumb is 16px white circle. Checked state shifts track to `#00D09C` and thumb remains `#121212` for clear contrast.